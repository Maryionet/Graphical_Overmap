Graphical overmap 1.0 Android 
1. download and extract the Overmap.zip file
2. place the overmap.png on the font folder located on com.cleverraven.cataclysmdda/files/font
3. override the font.json file on config but if you've made changes to the font.json file i suggest you edit it instead or backup the file. anyways it's located on com.cleverraven.cataclysmdda/files/config 

Changelogs
+Fixed the white and black bug 

Drawbacks with the solution
you lose color variability on buildings like shops etc


